require('dotenv').config();
const logger = require('./logger');

// Registered before anything else runs. Node's own guidance: don't try to
// "recover" from these — app state may already be inconsistent. Log clearly,
// exit, and let a process manager (pm2, systemd, Docker's restart policy, or
// the hosting platform's own supervisor) bring it back up clean.
//
// Important now that the DB is remote (Postgres/Supabase) rather than a local
// file: a single dropped connection or slow query must NOT reach these
// handlers. Every route below awaits its DB calls inside try/catch (or the
// global Express error handler further down), specifically so a routine,
// per-request DB hiccup fails *that request* with a 500 — not the whole
// server. These two handlers are reserved for genuinely unexpected bugs.
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception — shutting down:', err);
  process.exit(1);
});
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled promise rejection — shutting down:', reason);
  process.exit(1);
});

const express = require('express');
const helmet = require('helmet');
const multer = require('multer');
const path = require('path');
const crypto = require('crypto');

if (!process.env.ENCRYPTION_KEY || process.env.ENCRYPTION_KEY.length !== 64) {
  logger.error(
    'ENCRYPTION_KEY is missing or invalid in .env — it must be a 64-character hex string (32 bytes).\n' +
    'Generate one with: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"'
  );
  process.exit(1);
}

const db_ = require('./db');
const {
  initDb, migrate, createUser, getUserByEmail, getUserById, publicUser, markUserVerified,
  setUserGeminiKey, clearUserGeminiKey, updateUserPassword, deleteUserCompletely,
  createSession, getSession, deleteSession, deleteSessionsForUser, cleanupExpiredSessions,
  createEmailVerification, getEmailVerification, deleteEmailVerificationsForUser, cleanupExpiredVerifications,
  createPasswordReset, getPasswordReset, deletePasswordResetsForUser, cleanupExpiredPasswordResets,
  recordAttempt, countRecentFailures, clearFailures, cleanupOldLoginAttempts,
  listDrafts, getDraft, createDraft, updateDraft, deleteDraft, clearDrafts,
} = db_;
const {
  SESSION_TTL_MS, EMAIL_VERIFICATION_TTL_MS, PASSWORD_RESET_TTL_MS, LOGIN_ATTEMPT_RETENTION_MS,
  hashPassword, verifyPassword, newToken, encrypt, decrypt, requireAuth, rateLimitAuth,
} = require('./auth');
const { sendVerificationEmail, sendPasswordResetEmail } = require('./mailer');
const {
  PLATFORMS, MODEL, testGeminiKey, callGeminiJSON,
  ANALYZE_SYSTEM_PROMPT, LISTING_SYSTEM_PROMPT, analyzeParts, listingParts,
} = require('./gemini');

const BASE_URL = process.env.BASE_URL || `http://localhost:${process.env.PORT || 3001}`;

const app = express();

// Off by default on purpose: trusting X-Forwarded-* headers when there's no
// real proxy in front lets a client just lie about its own IP, which would
// make the per-IP rate-limit bucket worthless. Only turn this on when this
// server genuinely sits behind a reverse proxy / load balancer / PaaS that
// sets these headers itself and strips any client-supplied ones first.
if (process.env.TRUST_PROXY === 'true') {
  app.set('trust proxy', 1);
  logger.info('TRUST_PROXY enabled — req.ip now comes from X-Forwarded-For.');
}

// Sets HSTS, X-Content-Type-Options, X-Frame-Options, etc. The CSP here is
// intentionally permissive on inline scripts/styles — the app's own pages
// (public/index.html, the server-rendered verify/reset pages) use inline
// <script>/<style> rather than external files, so a strict CSP would break
// the app itself. 'unsafe-inline' is a known, documented trade-off: moving
// to external files + nonces would let this tighten further.
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", 'https://openfpcdn.io'],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:'], // thumbnails are data: URLs
      connectSrc: ["'self'"],
    },
  },
}));

// Off by default — most real deployments put this server behind something
// that already handles the HTTP→HTTPS redirect (a PaaS, nginx, Caddy).
// Enable only if this process itself needs to do the redirecting.
if (process.env.FORCE_HTTPS === 'true') {
  app.use((req, res, next) => {
    if (req.secure) return next();
    res.redirect(301, `https://${req.headers.host}${req.originalUrl}`);
  });
}

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json({ limit: '8mb' }));

// Constructing the Pool is synchronous (it doesn't connect eagerly) — safe to
// do here. Actually connecting/migrating happens in start(), at the bottom.
const db = initDb(process.env.DATABASE_URL);
const auth = requireAuth(db);
const rateLimited = rateLimitAuth(db);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function verifyPageHtml({ ok, message }) {
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Thriftly</title>
  <style>body{font-family:system-ui,sans-serif;max-width:400px;margin:80px auto;text-align:center;color:#1c1a17;padding:0 20px;}
  h1{font-size:18px;}p{color:#4a4438;font-size:14px;line-height:1.5;}
  a{display:inline-block;margin-top:14px;background:#1c1a17;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-size:13.5px;font-weight:600;}</style>
  </head><body><h1>${ok ? '✅ Email verified' : '⚠️ Verification failed'}</h1><p>${message}</p><a href="/">Continue to Thriftly</a></body></html>`;
}

// A small interactive page (not just a message) — resetting a password needs
// to collect the new one, which a plain link click can't do.
function resetPasswordPageHtml(token) {
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Reset your password</title>
  <style>body{font-family:system-ui,sans-serif;max-width:360px;margin:80px auto;color:#1c1a17;padding:0 20px;}
  h1{font-size:18px;text-align:center;}
  input{width:100%;border:1px solid #e6e2d8;border-radius:7px;padding:9px 11px;font:inherit;font-size:14px;margin-bottom:10px;box-sizing:border-box;}
  button{width:100%;padding:10px;border-radius:8px;border:none;background:#1c1a17;color:#fff;cursor:pointer;font-weight:600;font-size:14px;}
  #msg{font-size:13px;margin-top:10px;text-align:center;color:#a8462f;}
  #msg.ok{color:#54704A;}
  a{display:block;text-align:center;margin-top:14px;color:#1c1a17;font-size:13px;}</style>
  </head><body>
  <h1>Set a new password</h1>
  <form id="f">
    <input type="password" id="newPassword" placeholder="New password (min 8 characters)" minlength="8" required>
    <button type="submit">Reset password</button>
  </form>
  <div id="msg"></div>
  <a href="/">Back to Thriftly</a>
  <script>
    document.getElementById('f').addEventListener('submit', async (e) => {
      e.preventDefault();
      const newPassword = document.getElementById('newPassword').value;
      const msg = document.getElementById('msg');
      msg.className = ''; msg.textContent = '';
      try {
        const res = await fetch('/api/auth/reset-password', {
          method: 'POST', headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ token: ${JSON.stringify(token)}, newPassword }),
        });
        const data = await res.json();
        if (!res.ok) { msg.textContent = data.error || 'Something went wrong'; return; }
        document.getElementById('f').style.display = 'none';
        msg.className = 'ok';
        msg.textContent = 'Password updated — you can log in now.';
      } catch (err) {
        msg.textContent = 'Request failed: ' + err;
      }
    });
  </script>
  </body></html>`;
}

function sendError(res, err) {
  logger.error(err);
  const body = { error: err.message || 'Server error' };
  // In production, don't hand back provider error payloads or raw model output —
  // they can contain more than the client needs, and shouldn't be routine API surface.
  if (process.env.NODE_ENV !== 'production') {
    if (err.detail) body.detail = err.detail;
    if (err.raw) body.raw = err.raw;
  }
  res.status(err.status || 500).json(body);
}

// ============ AUTH ============
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !EMAIL_RE.test(email)) return res.status(400).json({ error: 'A valid email is required' });
    if (!password || password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
    if (await getUserByEmail(db, email)) return res.status(409).json({ error: 'An account with that email already exists' });

    const id = crypto.randomBytes(8).toString('hex');
    const user = await createUser(db, { id, email, passwordHash: hashPassword(password) });

    const token = newToken();
    await createEmailVerification(db, { token, userId: user.id, expiresAt: Date.now() + EMAIL_VERIFICATION_TTL_MS });
    const verifyUrl = `${BASE_URL}/api/auth/verify-email?token=${token}`;
    const mail = await sendVerificationEmail(email, verifyUrl);

    res.status(201).json({
      message: 'Account created — check your email to verify it before logging in.',
      // Only present when we couldn't actually email it (no SMTP configured, or sending failed) —
      // a real SMTP setup means this never appears. See README before relying on this for real users.
      devVerifyLink: mail.sent ? undefined : mail.devLink,
    });
  } catch (err) {
    sendError(res, err);
  }
});

app.get('/api/auth/verify-email', async (req, res) => {
  try {
    const token = req.query.token;
    const record = token && await getEmailVerification(db, token);
    if (!record || record.expires_at < Date.now()) {
      return res.status(400).send(verifyPageHtml({
        ok: false,
        message: 'This verification link is invalid or has expired. Go back and use "Resend verification email" to get a new one.',
      }));
    }
    await markUserVerified(db, record.user_id);
    await deleteEmailVerificationsForUser(db, record.user_id);
    res.send(verifyPageHtml({ ok: true, message: 'Your email is verified. You can log in now.' }));
  } catch (err) {
    sendError(res, err);
  }
});

app.post('/api/auth/resend-verification', rateLimited, async (req, res) => {
  try {
    const { email } = req.body || {};
    const { emailKey, ipKey, deviceKey } = req.rateLimitKeys;
    if (emailKey) await recordAttempt(db, emailKey);
    await recordAttempt(db, ipKey);
    if (deviceKey) await recordAttempt(db, deviceKey);

    // Always the same response, whether or not the account exists or is already verified —
    // don't let this endpoint be used to check who has an account.
    const generic = { message: 'If that email needs verifying, we just sent a new link.' };
    const user = email && await getUserByEmail(db, email);
    if (!user || user.email_verified) return res.json(generic);

    await deleteEmailVerificationsForUser(db, user.id);
    const token = newToken();
    await createEmailVerification(db, { token, userId: user.id, expiresAt: Date.now() + EMAIL_VERIFICATION_TTL_MS });
    const verifyUrl = `${BASE_URL}/api/auth/verify-email?token=${token}`;
    const mail = await sendVerificationEmail(email, verifyUrl);
    res.json({ ...generic, devVerifyLink: mail.sent ? undefined : mail.devLink });
  } catch (err) {
    sendError(res, err);
  }
});

app.post('/api/auth/login', rateLimited, async (req, res) => {
  try {
    const { email, password } = req.body || {};
    const { emailKey, ipKey, deviceKey } = req.rateLimitKeys;
    const user = email && await getUserByEmail(db, email);

    if (!user || !verifyPassword(password || '', user.password_hash)) {
      if (emailKey) await recordAttempt(db, emailKey);
      await recordAttempt(db, ipKey);
      if (deviceKey) await recordAttempt(db, deviceKey);
      return res.status(401).json({ error: 'Incorrect email or password' });
    }
    if (!user.email_verified) {
      return res.status(403).json({ error: 'Please verify your email before logging in', needsVerification: true });
    }

    if (emailKey) await clearFailures(db, emailKey); // this account just proved it's not being brute-forced
    if (deviceKey) await clearFailures(db, deviceKey);
    const token = newToken();
    await createSession(db, { token, userId: user.id, expiresAt: Date.now() + SESSION_TTL_MS });
    res.json({ token, user: publicUser(user) });
  } catch (err) {
    sendError(res, err);
  }
});

// ---------- password reset ----------
app.post('/api/auth/forgot-password', rateLimited, async (req, res) => {
  try {
    const { email } = req.body || {};
    const { emailKey, ipKey, deviceKey } = req.rateLimitKeys;
    // Every call counts toward the rate limit, valid email or not — spam doesn't require a real target.
    if (emailKey) await recordAttempt(db, emailKey);
    await recordAttempt(db, ipKey);
    if (deviceKey) await recordAttempt(db, deviceKey);

    // Same generic response either way — this endpoint must not reveal whether an email has an account.
    const generic = { message: 'If that email has an account, we just sent a password reset link.' };
    const user = email && await getUserByEmail(db, email);
    if (!user) return res.json(generic);

    await deletePasswordResetsForUser(db, user.id);
    const token = newToken();
    await createPasswordReset(db, { token, userId: user.id, expiresAt: Date.now() + PASSWORD_RESET_TTL_MS });
    const resetUrl = `${BASE_URL}/api/auth/reset-password?token=${token}`;
    const mail = await sendPasswordResetEmail(email, resetUrl);
    res.json({ ...generic, devResetLink: mail.sent ? undefined : mail.devLink });
  } catch (err) {
    sendError(res, err);
  }
});

app.get('/api/auth/reset-password', async (req, res) => {
  try {
    const token = req.query.token;
    const record = token && await getPasswordReset(db, token);
    if (!record || record.expires_at < Date.now()) {
      return res.status(400).send(verifyPageHtml({
        ok: false,
        message: 'This reset link is invalid or has expired. Go back and request a new one from the login screen.',
      }));
    }
    res.send(resetPasswordPageHtml(token));
  } catch (err) {
    sendError(res, err);
  }
});

app.post('/api/auth/reset-password', async (req, res) => {
  try {
    const { token, newPassword } = req.body || {};
    if (!newPassword || newPassword.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });

    const record = token && await getPasswordReset(db, token);
    if (!record || record.expires_at < Date.now()) {
      return res.status(400).json({ error: 'This reset link is invalid or has expired' });
    }

    await updateUserPassword(db, record.user_id, hashPassword(newPassword));
    await deletePasswordResetsForUser(db, record.user_id);
    await deleteSessionsForUser(db, record.user_id); // log out everywhere — the whole point of a reset is a fresh start
    res.json({ message: 'Password updated — you can log in now.' });
  } catch (err) {
    sendError(res, err);
  }
});

app.post('/api/auth/logout', auth, async (req, res) => {
  try {
    await deleteSession(db, req.token);
    res.status(204).end();
  } catch (err) {
    sendError(res, err);
  }
});

app.get('/api/auth/me', auth, (req, res) => {
  res.json(publicUser(req.user)); // req.user was already fetched by the auth middleware — no DB call here
});

// ============ ACCOUNT: Gemini key ============
app.post('/api/account/gemini-key', auth, async (req, res) => {
  try {
    const { apiKey } = req.body || {};
    if (!apiKey || apiKey.length < 10) return res.status(400).json({ error: 'A Gemini API key is required' });
    await testGeminiKey(apiKey); // cheap call — lists models, doesn't burn generation quota
    await setUserGeminiKey(db, req.userId, encrypt(apiKey));
    res.json({ connected: true });
  } catch (err) {
    sendError(res, err);
  }
});

app.delete('/api/account/gemini-key', auth, async (req, res) => {
  try {
    await clearUserGeminiKey(db, req.userId);
    res.status(204).end();
  } catch (err) {
    sendError(res, err);
  }
});

function usersGeminiKey(user) {
  if (!user.gemini_key_enc) return null;
  return decrypt(user.gemini_key_enc);
}

// ============ ACCOUNT: data rights ============
// Real people's data deserves a real way out — not just because it may be
// legally required (GDPR-style erasure/portability), but because handing
// this to strangers means honoring what they'd reasonably expect of any
// account they trust with their photos.
app.get('/api/account/export', auth, async (req, res) => {
  try {
    res.json({
      exportedAt: Date.now(),
      user: publicUser(req.user),
      drafts: await listDrafts(db, req.userId),
    });
  } catch (err) {
    sendError(res, err);
  }
});

app.delete('/api/account', auth, async (req, res) => {
  try {
    const { password } = req.body || {};
    if (!password || !verifyPassword(password, req.user.password_hash)) {
      return res.status(401).json({ error: 'Incorrect password' });
    }
    await deleteUserCompletely(db, req.userId);
    res.status(204).end();
  } catch (err) {
    sendError(res, err);
  }
});

// ============ THE REAL PIPELINE ============

// Photo in -> identify + price it (using THIS user's own Gemini key) -> save as a new draft
app.post('/api/scan', auth, upload.single('photo'), async (req, res) => {
  try {
    const apiKey = usersGeminiKey(req.user);
    if (!apiKey) return res.status(400).json({ error: 'Connect your Gemini API key in Settings before scanning' });
    if (!req.file) return res.status(400).json({ error: 'No photo uploaded — send multipart/form-data with field name "photo"' });
    const allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowed.includes(req.file.mimetype)) {
      return res.status(400).json({ error: `Unsupported image type: ${req.file.mimetype}. Use jpeg, png, gif, or webp.` });
    }

    const base64 = req.file.buffer.toString('base64');
    const analysis = await callGeminiJSON({
      apiKey, system: ANALYZE_SYSTEM_PROMPT, parts: analyzeParts(base64, req.file.mimetype),
    });

    const thumb = `data:${req.file.mimetype};base64,${base64}`;
    const draft = await createDraft(db, req.userId, { analysis, thumb, selected: PLATFORMS });
    res.status(201).json(draft);
  } catch (err) {
    sendError(res, err);
  }
});

// Saved analysis -> real per-platform listing drafts (using THIS user's own key) -> saved back
app.post('/api/drafts/:id/generate-listing', auth, async (req, res) => {
  try {
    const apiKey = usersGeminiKey(req.user);
    if (!apiKey) return res.status(400).json({ error: 'Connect your Gemini API key in Settings before generating listings' });

    const existing = await getDraft(db, req.userId, req.params.id);
    if (!existing) return res.status(404).json({ error: 'Draft not found' });

    const generated = await callGeminiJSON({
      apiKey, system: LISTING_SYSTEM_PROMPT, parts: listingParts(existing.analysis), maxTokens: 900,
    });

    const missing = PLATFORMS.filter(p => !generated[p]);
    if (missing.length) return res.status(502).json({ error: `Model response was missing: ${missing.join(', ')}`, raw: generated });

    const listingsPatch = {};
    for (const platform of PLATFORMS) {
      listingsPatch[platform] = { ...generated[platform], posted: existing.listings[platform]?.posted || false };
    }

    res.json(await updateDraft(db, req.userId, req.params.id, { listings: listingsPatch }));
  } catch (err) {
    sendError(res, err);
  }
});

// ============ DRAFT CRUD (all scoped to the logged-in user) ============
app.get('/api/drafts', auth, async (req, res) => {
  try {
    res.json(await listDrafts(db, req.userId));
  } catch (err) {
    sendError(res, err);
  }
});

app.get('/api/drafts/:id', auth, async (req, res) => {
  try {
    const draft = await getDraft(db, req.userId, req.params.id);
    if (!draft) return res.status(404).json({ error: 'Draft not found' });
    res.json(draft);
  } catch (err) {
    sendError(res, err);
  }
});

app.put('/api/drafts/:id', auth, async (req, res) => {
  try {
    const updated = await updateDraft(db, req.userId, req.params.id, req.body || {});
    if (!updated) return res.status(404).json({ error: 'Draft not found' });
    res.json(updated);
  } catch (err) {
    sendError(res, err);
  }
});

app.delete('/api/drafts/:id', auth, async (req, res) => {
  try {
    const existing = await getDraft(db, req.userId, req.params.id);
    if (!existing) return res.status(404).json({ error: 'Draft not found' });
    await deleteDraft(db, req.userId, req.params.id);
    res.status(204).end();
  } catch (err) {
    sendError(res, err);
  }
});

app.delete('/api/drafts', auth, async (req, res) => {
  try {
    await clearDrafts(db, req.userId);
    res.status(204).end();
  } catch (err) {
    sendError(res, err);
  }
});

// A real connectivity check now, not just "the process is up" — pings
// Postgres directly, since with a remote DB those are two different things
// a monitor genuinely needs to tell apart.
app.get('/api/health', async (_req, res) => {
  try {
    await db.query('SELECT 1');
    res.json({ ok: true, model: MODEL, database: 'connected' });
  } catch (err) {
    res.status(503).json({ ok: false, model: MODEL, database: 'unreachable' });
  }
});

// Catches anything that reaches here without a route already having handled it —
// e.g. a Multer error (file too large) fires before any route's own try/catch
// ever runs. Without this, Express's default handler would return a raw HTML
// stack trace instead of clean JSON.
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  logger.error(`Unhandled error on ${req.method} ${req.path}:`, err);
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production' ? 'Something went wrong' : (err.message || 'Server error'),
  });
});

const PORT = process.env.PORT || 3001;

// Everything above just wires up routes — no query has actually run yet.
// Connect, migrate the schema, run startup cleanup, and only *then* start
// accepting requests, so nothing can hit the database before it's ready.
async function start() {
  await migrate(db);
  await cleanupExpiredSessions(db);
  await cleanupExpiredVerifications(db);
  await cleanupExpiredPasswordResets(db);
  await cleanupOldLoginAttempts(db, LOGIN_ATTEMPT_RETENTION_MS);
  app.listen(PORT, () => logger.info(`Thriftly backend (multi-user, Gemini-powered, Postgres) listening on port ${PORT}`));
}

start().catch((err) => {
  logger.error('Failed to start server:', err);
  process.exit(1);
});

process.on('SIGINT', async () => {
  await db.end(); // pg.Pool's close method — not better-sqlite3's .close()
  process.exit(0);
});
