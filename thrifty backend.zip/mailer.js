const nodemailer = require('nodemailer');

let transporter = null;
function getTransporter() {
  if (!process.env.SMTP_HOST) return null; // no SMTP configured — caller falls back to dev mode
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === 'true',
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    });
  }
  return transporter;
}

// Shared send-or-log core. Returns { sent: true } on a real send, or
// { sent: false, devLink } when there's no SMTP configured (or sending
// failed) — so local dev never gets blocked waiting on an email that was
// never going to arrive.
async function sendOrLog({ to, subject, text, html, fallbackLink }) {
  const t = getTransporter();
  if (!t) {
    console.log(`\n[dev mode — no SMTP configured] Link for ${to}:\n${fallbackLink}\n`);
    return { sent: false, devLink: fallbackLink };
  }
  try {
    await t.sendMail({ from: process.env.SMTP_FROM || process.env.SMTP_USER, to, subject, text, html });
    return { sent: true };
  } catch (err) {
    console.error('Failed to send email:', err.message);
    console.log(`[fallback] Link for ${to}:\n${fallbackLink}\n`);
    return { sent: false, error: err.message, devLink: fallbackLink };
  }
}

function sendVerificationEmail(to, verifyUrl) {
  return sendOrLog({
    to,
    subject: 'Verify your Thriftly account',
    text: `Welcome to Thriftly! Verify your email to finish setting up your account:\n\n${verifyUrl}\n\nThis link expires in 24 hours.`,
    html: `<p>Welcome to Thriftly! Verify your email to finish setting up your account:</p><p><a href="${verifyUrl}">${verifyUrl}</a></p><p>This link expires in 24 hours.</p>`,
    fallbackLink: verifyUrl,
  });
}

function sendPasswordResetEmail(to, resetUrl) {
  return sendOrLog({
    to,
    subject: 'Reset your Thriftly password',
    text: `Someone (hopefully you) asked to reset the password on your Thriftly account:\n\n${resetUrl}\n\nThis link expires in 1 hour. If you didn't request this, you can ignore this email — your password won't change.`,
    html: `<p>Someone (hopefully you) asked to reset the password on your Thriftly account:</p><p><a href="${resetUrl}">${resetUrl}</a></p><p>This link expires in 1 hour. If you didn't request this, you can ignore this email — your password won't change.</p>`,
    fallbackLink: resetUrl,
  });
}

module.exports = { sendVerificationEmail, sendPasswordResetEmail };
