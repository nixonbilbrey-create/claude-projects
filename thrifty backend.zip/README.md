# Thriftly Backend — multi-user, bring-your-own-key, Gemini-powered

Real accounts. Each user connects their own Gemini API key. Every scan and
every generated listing runs on *their* key, not a shared one you pay for.
This is the shape that makes "free for me and the users" actually true: you
never pay for anyone's usage — each person's own free-tier Gemini key funds
their own use of the app.

```
signup ──► account created, unverified ──► verification email sent
                                               │ (console link if no SMTP configured)
                                               ▼
                                  click link ──► email verified
                                               │
login (rate-limited) ────────────────────────►│
                    │                          (blocked until verified)
                    ▼
             session token
                    │
                    ▼
Settings: paste a Gemini key ──► validated live, encrypted, stored per-user
                    │
                    ▼
POST /api/scan (their key) ──► Gemini identifies the item + estimates price
                    │            └─ saved as a new draft, owned by them
                    ▼
POST /api/drafts/:id/generate-listing (their key) ──► 4 platform listings
                    │                                    └─ saved onto the draft
                    ▼
GET/PUT/DELETE /api/drafts ──► only ever their own drafts

Forgot password (rate-limited) ──► reset email sent ──► click link ──►
   set a new password ──► all existing sessions revoked, log in again
```

## Why this isn't Claude anymore

Claude's API has no ongoing free tier — a one-time signup credit, then it's
paid. Google's Gemini API does have a real, renewing free tier, which is
what makes a $0-for-the-operator model possible. That's the whole reason
this backend now calls `generativelanguage.googleapis.com` instead of
`api.anthropic.com`. Worth knowing: free-tier usage on most providers,
Google included, generally means your inputs may be used to improve their
models — a real tradeoff for real photos, different from a paid tier's
usual privacy terms. Confirm current terms before relying on this for
anything sensitive.

## Setup

**1. Create a Supabase project** (free, no credit card) at
[supabase.com](https://supabase.com) → New Project. Takes a minute or two to
provision.

**2. Get the right connection string.** In your project: **Connect** button
(top of the dashboard) → **Session pooler** tab specifically — not "Direct
connection," not "Transaction pooler." This app is a long-running server, not
a serverless function, and Session pooler is what Supabase's own docs
recommend for that: it works over IPv4 (Direct connection is IPv6-only
unless you pay for an add-on), and unlike Transaction pooler, it supports
prepared statements, which this app uses. Copy the whole string — it
includes your database password.

**3. Run it:**

```
cd thriftly-backend
npm install
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"   # copy this
cp .env.example .env    # paste that value in as ENCRYPTION_KEY, and your connection string as DATABASE_URL
npm start
```

The first run creates every table automatically (see `migrate()` in
`db.js`) — nothing to run manually in Supabase's SQL editor.

Open **http://localhost:3001** — sign up, then check the **server console**
for a verification link (no SMTP is configured by default, so links print
there instead of emailing — the signup response also includes `devVerifyLink`
for the same reason). Click it, log in, connect a Gemini key (the page links
straight to https://aistudio.google.com/apikey), then scan a photo.

To send real verification emails instead of console links, fill in
`SMTP_HOST`/`SMTP_USER`/`SMTP_PASS`/etc. in `.env` with any SMTP provider
(Gmail app password, SendGrid, Mailgun, Resend's SMTP relay, ...) and set
`BASE_URL` to wherever this server is actually reachable.

Each person who runs or uses this needs their **own** Gemini key — there's
no key baked into the server. That's the point.

## Endpoints

**Auth**
| Method | Path | Does what |
|---|---|---|
| POST | `/api/auth/signup` | `{email, password}` → creates an **unverified** account, sends (or logs) a verification link, returns a message (plus `devVerifyLink` if no SMTP is configured) |
| GET | `/api/auth/verify-email?token=` | The link from that email — marks the account verified, shows a small confirmation page |
| POST | `/api/auth/resend-verification` | `{email}` → sends a new link if that account needs one. Always returns the same generic message either way, so this can't be used to check who has an account |
| POST | `/api/auth/login` | `{email, password}` → `{token, user}`. Returns 403 with `needsVerification: true` if the account isn't verified yet. Rate-limited (see below) |
| POST | `/api/auth/forgot-password` | `{email}` → always the same generic message, whether or not that email has an account (plus `devResetLink` if no SMTP is configured) |
| GET | `/api/auth/reset-password?token=` | The link from that email — a small standalone page to set a new password |
| POST | `/api/auth/logout` | Invalidates the current session |
| GET | `/api/auth/me` | Current user + verification status + whether a Gemini key is connected |

### Rate limiting

`/api/auth/login`, `/api/auth/forgot-password`, and `/api/auth/resend-verification`
are all rate-limited by **three** independent counters: **5 attempts per
email**, **20 per IP address**, and **8 per device fingerprint**
(FingerprintJS, open-source v3 — pinned deliberately, since v4+ is
Business-Source-licensed for non-production use only), all within a rolling
15-minute window, tracked in the `login_attempts` table so it survives a
server restart. Every call to these three endpoints counts — not just wrong
passwords — since spam doesn't need a correct guess to be a problem. A
successful login clears that email's and device's counters; failures don't,
so an attacker can't reset their own clock by getting lucky once.

The device layer degrades gracefully: an ad blocker or strict tracking
protection can block FingerprintJS entirely, in which case the app just
falls back to email+IP protection — it never blocks anyone from using the
app. Even with all three signals, this raises the bar rather than making
brute-forcing impossible — see Security notes below.

Set `TRUST_PROXY=true` in `.env` **only if** this server genuinely sits
behind a reverse proxy / load balancer / PaaS that sets `X-Forwarded-*`
headers itself. Leaving it `false` behind a real proxy makes every request
look like it's coming from the proxy's own IP (the per-IP bucket becomes
useless); turning it `true` with **no** real proxy in front lets any client
just lie about its own IP in that same header (worse than useless — it
becomes a way to *evade* the limit). Get this one right for your actual setup.

All routes below require `Authorization: Bearer <token>`.

**Account**
| Method | Path | Does what |
|---|---|---|
| POST | `/api/account/gemini-key` | `{apiKey}` → validates it live against Google (a free models-list call, not a billed generation), then encrypts and stores it |
| DELETE | `/api/account/gemini-key` | Removes the stored key |
| GET | `/api/account/export` | Everything tied to you — profile (minus your password hash and raw Gemini key) plus every draft — as downloadable JSON |
| DELETE | `/api/account` | `{password}` → permanently deletes the account and everything that references it (drafts, sessions, verification/reset tokens, rate-limit history), in one transaction. Requires your current password even with a valid session, so a stolen token alone can't nuke the account |

**The pipeline**
| Method | Path | Does what |
|---|---|---|
| POST | `/api/scan` | `multipart/form-data`, field `photo` → identifies + prices the item using **your** key, saves it, returns the draft |
| POST | `/api/drafts/:id/generate-listing` | Drafts real per-platform copy using **your** key, saves it onto the draft. Re-callable — refreshes copy, keeps any `posted` flags. |
| GET/PUT/DELETE | `/api/drafts[/:id]` | Full CRUD, always scoped to the logged-in user — nobody can see or touch another user's drafts |

## Deployment & production readiness

Everything in this section is about running this somewhere real people can
reach — none of it matters for local testing. For the actual step-by-step
(Render + this repo's `render.yaml`), see **[DEPLOYMENT.md](./DEPLOYMENT.md)**.

- **The original hosting blocker is solved.** Every "free Node hosting"
  platform we found either wipes local disk on every restart/redeploy, or
  isn't really free anymore — fatal for a database that used to live in a
  local SQLite file. It doesn't anymore: all persistence now lives on
  Supabase, so the compute host's disk being ephemeral genuinely doesn't
  matter. That's the whole point of this migration — it turns "find a free
  host with persistent disk" (hard, arguably doesn't exist right now) into
  "find any free host that can run a Node process" (easy — Render's free
  Web Services work fine for this now).
- **HTTPS.** This app doesn't terminate TLS itself by default — most real
  deployments sit behind something that already does (a PaaS like Render or
  Railway, or your own nginx/Caddy in front). If *this process* needs to
  redirect HTTP→HTTPS itself, set `FORCE_HTTPS=true`. Either way, set
  `TRUST_PROXY=true` too if there's a real proxy in front (see Rate limiting
  above for why getting this wrong is worse than leaving it off).
- **Security headers** come from `helmet` (HSTS, `X-Content-Type-Options`,
  `X-Frame-Options`, a Content-Security-Policy, and more) — on automatically,
  no config needed. One honest trade-off: the CSP allows `'unsafe-inline'`
  for scripts and styles, because the app's own pages use inline
  `<script>`/`<style>` rather than external files. Moving those to external
  files with a nonce-based CSP would let this tighten further; it's not done
  here.
- **Crashes are visible and recoverable, not silent.** `logger.js` timestamps
  and levels everything. Uncaught exceptions and unhandled promise
  rejections are logged clearly and then **exit the process on purpose** —
  Node's own guidance is not to try to keep running after one of these,
  since app state may already be broken. That means **you need a process
  manager** (`pm2`, systemd, Docker's restart policy, or your host's own
  supervisor) to actually bring it back up — without one, a crash just stays
  crashed.
- **`NODE_ENV=production`** hides internal error detail (provider error
  payloads, raw model output, stack-shaped messages) from API responses —
  set it once this is deployed. Left unset, error responses are more verbose
  on purpose, to make local debugging easier.
- **No error-tracking or uptime monitoring is wired up.** `logger.js` writes
  to stdout/stderr; capturing and alerting on that (a log drain, or a service
  like Sentry) is on you — that's genuinely more infrastructure than a
  backend README should assume you want, but it's the natural next step once
  this is live.

## Security notes — read before trusting this with real users

This is a real, working multi-user system, but it's a starter one. Specifically:

- **Gemini keys are encrypted at rest** (AES-256-GCM, keyed by your server's
  `ENCRYPTION_KEY`) — not stored as plain text. But whoever controls that
  env var can decrypt every stored key, so protect it like the secret it is.
- **Passwords are hashed** with bcrypt, never stored in plain text.
- **Email verification, password reset, three-layer rate limiting
  (email/IP/device), security headers, and account deletion/export all
  exist now.** Resets revoke every existing session for that account, a
  stolen session token alone can't delete an account (your password is
  required even while logged in), and reset/verify tokens are single-use
  and time-limited (1 hour / 24 hours).
- **Still genuinely open:** no email-address-change flow, no 2FA. Rate
  limiting raises the bar significantly but isn't absolute — a patient
  attacker with many IPs, many emails, and spoofed-or-cleared fingerprints
  can still grind slowly under the thresholds. Fine for a small real user
  base; worth revisiting (CAPTCHA on repeated failures, stricter thresholds,
  a WAF in front) before this is genuinely public-facing at scale.
- **In dev mode (no SMTP configured), verification and reset links are
  returned directly in the API response** as a convenience so testing
  isn't blocked on an email that was never sent. This must not ship that
  way to real users — configure SMTP for anyone but yourself, or remove
  the `devVerifyLink`/`devResetLink` fallbacks entirely before that happens.
- **Sessions are simple bearer tokens** stored in Postgres, 30-day expiry, no
  refresh flow. Logging out deletes the row; that's the whole revocation
  story.
- **No automated tests.** Everything here has been syntax-checked and had
  its imports cross-referenced carefully, but there's no test suite that
  would catch a regression automatically as this keeps changing.
- **Photos are still stored full-size as base64** in the `drafts` table —
  fine for testing, worth fixing (resize, or store outside the DB) before
  real volume.
- **No pagination on `/api/drafts`** — fine at dozens of drafts per user,
  not at thousands.
- **The DB is remote now, not a local file** — every query can fail in ways
  a local file basically never does (a dropped connection, a slow network).
  Every route awaits its DB calls inside try/catch specifically so one of
  those failures returns a clean 500 to that one request, instead of taking
  the whole server down — verified line-by-line, not just spot-checked,
  given how much rode on getting this right.

## What changed from the single-user version

- `analysis`/`listings` on a draft are unchanged in shape.
- Every draft now has a `user_id` and every query is scoped to it.
- The AI provider swapped from Anthropic (server-paid) to Gemini
  (user-paid) — same two-step pipeline, same JSON contract, different
  vendor underneath.
- Signup no longer logs you in immediately — accounts start unverified,
  and `mailer.js` handles sending (or, without SMTP configured, logging)
  the verification link.
- Forgot your password? `mailer.js` sends (or logs) a reset link; using it
  sets a new password and signs you out everywhere else, on purpose.
- Login, forgot-password, and resend-verification are all rate-limited
  against brute-forcing and spam, backed by a real `login_attempts` table
  rather than an in-memory counter that forgets everything on restart —
  now with a third bucket (device fingerprint, via FingerprintJS v3) on
  top of email and IP.
- Security headers (`helmet`), safe opt-in `TRUST_PROXY`/`FORCE_HTTPS`
  handling, structured crash-visible logging (`logger.js`), and real
  account deletion/data export — the "safe to hand to strangers" pass.
- **Storage moved from a local SQLite file to Supabase (hosted Postgres)** —
  the reason: no free hosting platform we could verify offers both an
  ongoing free compute tier *and* persistent local disk, which is fatal for
  a database that lives in a file. This was the single biggest code change
  in the project: `better-sqlite3` is synchronous, `pg` is async, so every
  function in `db.js` and every call site in `server.js`/`auth.js` changed
  shape, not just the SQL dialect. One nice side effect: `pg` has no native
  addon to compile, so `npm install` is simpler and more portable than it
  was with `better-sqlite3`.
- `ebay-auto-post` is still its own separate project, still on hold.

## Project layout

```
thriftly-backend/
├── server.js       # routes
├── db.js           # Postgres (Supabase) schema + queries, via pg
├── auth.js         # passwords, sessions, encryption, rate limiting
├── gemini.js       # Gemini API calls + prompts
├── mailer.js       # sends (or logs) verification/reset emails
├── logger.js       # timestamped, leveled logging
├── package.json
├── .env.example
└── public/
    └── index.html  # the test harness — must live under public/, not the root
```
