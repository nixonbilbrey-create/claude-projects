function ts() {
  return new Date().toISOString();
}

function info(...args) {
  console.log(`[${ts()}] INFO`, ...args);
}
function warn(...args) {
  console.warn(`[${ts()}] WARN`, ...args);
}
function error(...args) {
  console.error(`[${ts()}] ERROR`, ...args);
}

module.exports = { info, warn, error };
