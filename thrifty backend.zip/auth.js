const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const EMAIL_VERIFICATION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
const PASSWORD_RESET_TTL_MS = 60 * 60 * 1000; // 1 hour — shorter than verification, since it grants account access

// Login rate limiting: three independent buckets. Per-email catches someone
// hammering one account; per-IP catches someone hammering many accounts from
// one machine; per-device catches someone hopping across IPs (VPNs, mobile
// networks, botnets) while staying on the same browser/device. The IP
// threshold is loosest since IPs are legitimately shared (offices, NAT,
// campus and carrier networks) by many unrelated people — a device
// fingerprint is a much smaller crowd, but not zero: FingerprintJS's
// open-source version has real collision (~40-60% accuracy), so it isn't
// as tight as the per-email bucket either.
const LOGIN_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
const MAX_ATTEMPTS_PER_EMAIL = 5;
const MAX_ATTEMPTS_PER_IP = 20;
const MAX_ATTEMPTS_PER_DEVICE = 8;
const LOGIN_ATTEMPT_RETENTION_MS = 24 * 60 * 60 * 1000; // keep 24h of history, prune the rest

// A FingerprintJS v3 visitorId is a short hex/base64-ish hash. This just
// guards against someone sending an absurd or malformed value as the header —
// it's not validating that the fingerprint is "real" in any deeper sense.
const FINGERPRINT_RE = /^[a-zA-Z0-9_-]{8,128}$/;

// ---------- passwords ----------
function hashPassword(password) {
  return bcrypt.hashSync(password, 10);
}
function verifyPassword(password, hash) {
  return bcrypt.compareSync(password, hash);
}

// ---------- session tokens ----------
function newToken() {
  return crypto.randomBytes(32).toString('hex');
}

// ---------- at-rest encryption for stored Gemini keys (AES-256-GCM) ----------
function getEncryptionKey() {
  const hex = process.env.ENCRYPTION_KEY;
  if (!hex || hex.length !== 64) {
    throw new Error(
      'ENCRYPTION_KEY must be set in .env as a 64-character hex string (32 bytes). ' +
      'Generate one with: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"'
    );
  }
  return Buffer.from(hex, 'hex');
}

function encrypt(plaintext) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', getEncryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv.toString('hex'), tag.toString('hex'), encrypted.toString('hex')].join(':');
}

function decrypt(payload) {
  const [ivHex, tagHex, dataHex] = payload.split(':');
  const decipher = crypto.createDecipheriv('aes-256-gcm', getEncryptionKey(), Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  const decrypted = Buffer.concat([decipher.update(Buffer.from(dataHex, 'hex')), decipher.final()]);
  return decrypted.toString('utf8');
}

// ---------- auth middleware ----------
// Reads "Authorization: Bearer <token>", looks the session up, attaches req.userId / req.user.
// Async now that the DB layer is — errors go to next(err) so a dropped DB
// connection fails *this request* with a clean 500, not the whole process.
function requireAuth(db) {
  const { getSession, getUserById } = require('./db');
  return async (req, res, next) => {
    try {
      const header = req.headers.authorization || '';
      const token = header.startsWith('Bearer ') ? header.slice(7) : null;
      if (!token) return res.status(401).json({ error: 'Missing Authorization header (Bearer token)' });

      const session = await getSession(db, token);
      if (!session || session.expires_at < Date.now()) {
        return res.status(401).json({ error: 'Invalid or expired session — log in again' });
      }
      const user = await getUserById(db, session.user_id);
      if (!user) return res.status(401).json({ error: 'User not found' });

      req.token = token;
      req.userId = user.id;
      req.user = user;
      next();
    } catch (err) {
      next(err);
    }
  };
}

// ---------- login/signup abuse rate limiting ----------
// Applied to login, forgot-password, and resend-verification — anything that
// takes an email and either checks a password or sends mail is a target for
// brute-forcing or spam. Blocks *before* the route handler runs; the handler
// itself records the attempt (see server.js) — every call to these three
// routes counts, not just failed ones, since spam doesn't require a wrong
// password to be a problem.
function rateLimitAuth(db) {
  const { countRecentFailures } = require('./db');
  return async (req, res, next) => {
    try {
      const email = (req.body?.email || '').trim().toLowerCase();
      const ip = req.ip;
      const rawFingerprint = req.headers['x-device-fingerprint'];
      const fingerprint = typeof rawFingerprint === 'string' && FINGERPRINT_RE.test(rawFingerprint) ? rawFingerprint : null;

      req.rateLimitKeys = {
        emailKey: email ? `email:${email}` : null,
        ipKey: `ip:${ip}`,
        deviceKey: fingerprint ? `device:${fingerprint}` : null, // null when absent or malformed — that layer just doesn't apply
      };

      const emailFails = req.rateLimitKeys.emailKey ? await countRecentFailures(db, req.rateLimitKeys.emailKey, LOGIN_WINDOW_MS) : 0;
      const ipFails = await countRecentFailures(db, req.rateLimitKeys.ipKey, LOGIN_WINDOW_MS);
      const deviceFails = req.rateLimitKeys.deviceKey ? await countRecentFailures(db, req.rateLimitKeys.deviceKey, LOGIN_WINDOW_MS) : 0;

      if (emailFails >= MAX_ATTEMPTS_PER_EMAIL || ipFails >= MAX_ATTEMPTS_PER_IP || deviceFails >= MAX_ATTEMPTS_PER_DEVICE) {
        const minutes = Math.ceil(LOGIN_WINDOW_MS / 60000);
        return res.status(429).json({ error: `Too many attempts. Please wait about ${minutes} minutes and try again.` });
      }
      next();
    } catch (err) {
      next(err);
    }
  };
}

module.exports = {
  SESSION_TTL_MS, EMAIL_VERIFICATION_TTL_MS, PASSWORD_RESET_TTL_MS,
  LOGIN_WINDOW_MS, MAX_ATTEMPTS_PER_EMAIL, MAX_ATTEMPTS_PER_IP, MAX_ATTEMPTS_PER_DEVICE, LOGIN_ATTEMPT_RETENTION_MS,
  hashPassword, verifyPassword, newToken, encrypt, decrypt, requireAuth, rateLimitAuth,
};
