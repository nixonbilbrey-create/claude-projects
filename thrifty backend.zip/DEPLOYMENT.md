# Deploying Thriftly Backend

This assumes you've already followed the README's Setup section far enough
to have a Supabase project and its **Session pooler** connection string —
that's the one real prerequisite. Everything below is about getting the
*server* live, not the database (that part's already hosted).

## 1. Push this to GitHub

Render deploys from a Git repo, not a local folder.

```
cd thriftly-backend
git init
git add .
git commit -m "Thriftly backend"
```

Create a new repo on GitHub, then push to it (`git remote add origin ...`,
`git push -u origin main`). `.gitignore` already excludes `node_modules/`
and `.env` — your secrets never leave your machine this way.

## 2. Create a Render account

[render.com](https://render.com) — free, no credit card required for the
free tier used here.

## 3. Deploy via Blueprint (not the manual "New Web Service" flow)

`render.yaml` is already in this repo — it defines the service so you don't
hand-configure build/start commands and health checks by clicking through
the dashboard, which is easy to get subtly wrong.

**Dashboard → New + → Blueprint → connect the repo you just pushed.**
Render reads `render.yaml` automatically and shows you the service it's
about to create.

## 4. Fill in the three prompts

Render will ask for the three values marked `sync: false` in `render.yaml`
— it won't proceed without them:

- **`DATABASE_URL`** — the Supabase Session pooler string from the README's
  Setup section.
- **`ENCRYPTION_KEY`** — generate this **locally first**, don't use Render's
  own "generate" option here: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`.
  Render's auto-generate makes a base64 secret; this app's code specifically
  requires a 64-character hex string, so Render's version would fail
  validation on every startup. Paste the hex one.
- **`BASE_URL`** — best guess: `https://thriftly-backend.onrender.com`
  (Render service names are globally unique, so if that's already taken,
  Render will assign a different slug — check the actual URL after step 5
  and come back to fix this if it's wrong, then redeploy).

## 5. Deploy

Click deploy, watch the build log. First build installs dependencies and
starts the server — `pg` has no native addon to compile, so this should be
quick and shouldn't hit the build-tools issues `better-sqlite3` used to risk.

## 6. Verify it's actually live and actually connected to Supabase

Visit `https://<your-service>.onrender.com/api/health`. You should see:

```json
{ "ok": true, "model": "gemini-3.5-flash", "database": "connected" }
```

`"database": "connected"` means it's a real, live query to Supabase, not
just "the process didn't crash." If this comes back `"unreachable"`, the
DATABASE_URL is the first thing to check — the README's Setup section has
the exact Session-pooler-not-Direct-connection guidance that most commonly
trips this up.

Then visit the root URL, sign up, and check the **Render logs** (Dashboard
→ Logs) for the dev-mode verification link — same behavior as running
locally, since SMTP isn't configured yet.

## 7. Two things worth knowing before you call this "live"

- **Cold starts.** Render's free tier sleeps after 15 minutes of no
  traffic; the next request takes 30–60 seconds to wake it back up. That's
  a real UX cost, not a bug. If it matters, Render's Starter plan (~$7/mo)
  removes it — the README's "Path C" from the original hosting discussion.
- **No real email yet.** Verification and reset links are still printing to
  Render's logs instead of being emailed, same dev-mode fallback as local.
  Add `SMTP_HOST`/`SMTP_USER`/`SMTP_PASS`/etc. in Render's dashboard
  (Environment tab) once you're ready to send real email — no redeploy of
  code needed, just the env vars, then a restart.
