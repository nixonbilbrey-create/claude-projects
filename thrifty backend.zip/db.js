const { Pool, types } = require('pg');

// node-postgres returns BIGINT (OID 20) as a JS *string* by default, since a
// 64-bit integer can exceed Number.MAX_SAFE_INTEGER. Our BIGINTs are all
// epoch-millisecond timestamps or COUNT(*) results — nowhere near that limit
// — so it's safe (and much simpler for the rest of this file) to have the
// driver hand them back as real numbers instead.
types.setTypeParser(20, (val) => parseInt(val, 10));

function initDb(connectionString) {
  const conn = connectionString || process.env.DATABASE_URL;
  if (!conn) {
    throw new Error(
      'DATABASE_URL is not set. Use your Supabase project\'s Session pooler connection ' +
      'string (Dashboard → Connect → Session pooler) — see README for why that one specifically.'
    );
  }
  return new Pool({
    connectionString: conn,
    ssl: { rejectUnauthorized: false }, // Supabase requires SSL; see README for a stricter alternative
  });
}

// Creates every table/index if missing. Safe to run on every startup — all
// of this is idempotent.
async function migrate(db) {
  await db.query(`
    CREATE TABLE IF NOT EXISTS users (
      id                    TEXT PRIMARY KEY,
      email                 TEXT NOT NULL UNIQUE,
      password_hash         TEXT NOT NULL,
      email_verified        BOOLEAN NOT NULL DEFAULT false,
      gemini_key_enc        TEXT,
      gemini_key_valid      BOOLEAN NOT NULL DEFAULT false,
      gemini_key_updated_at BIGINT,
      created_at            BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token       TEXT PRIMARY KEY,
      user_id     TEXT NOT NULL,
      created_at  BIGINT NOT NULL,
      expires_at  BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS email_verifications (
      token       TEXT PRIMARY KEY,
      user_id     TEXT NOT NULL,
      created_at  BIGINT NOT NULL,
      expires_at  BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS password_resets (
      token       TEXT PRIMARY KEY,
      user_id     TEXT NOT NULL,
      created_at  BIGINT NOT NULL,
      expires_at  BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS login_attempts (
      id          SERIAL PRIMARY KEY,
      identifier  TEXT NOT NULL,
      created_at  BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS drafts (
      id          TEXT PRIMARY KEY,
      user_id     TEXT NOT NULL,
      analysis    TEXT NOT NULL,
      thumb       TEXT,
      listings    TEXT NOT NULL DEFAULT '{}',
      selected    TEXT NOT NULL DEFAULT '[]',
      created_at  BIGINT NOT NULL,
      updated_at  BIGINT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_drafts_user ON drafts(user_id);
    CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
    CREATE INDEX IF NOT EXISTS idx_email_verifications_user ON email_verifications(user_id);
    CREATE INDEX IF NOT EXISTS idx_password_resets_user ON password_resets(user_id);
    CREATE INDEX IF NOT EXISTS idx_login_attempts_lookup ON login_attempts(identifier, created_at);
  `);
  // Postgres supports IF NOT EXISTS directly here — no try/catch hack needed
  // the way SQLite required for this same safety-net migration.
  await db.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified BOOLEAN NOT NULL DEFAULT false');
}

function normalizeEmail(email) {
  return email.trim().toLowerCase();
}

// ---------- users ----------
async function createUser(db, { id, email, passwordHash }) {
  const now = Date.now();
  const result = await db.query(
    `INSERT INTO users (id, email, password_hash, gemini_key_valid, created_at)
     VALUES ($1, $2, $3, false, $4) RETURNING *`,
    [id, normalizeEmail(email), passwordHash, now],
  );
  return result.rows[0];
}

async function getUserByEmail(db, email) {
  const result = await db.query('SELECT * FROM users WHERE email = $1', [normalizeEmail(email)]);
  return result.rows[0] || null;
}

async function getUserById(db, id) {
  const result = await db.query('SELECT * FROM users WHERE id = $1', [id]);
  return result.rows[0] || null;
}

function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    email: user.email,
    emailVerified: !!user.email_verified,
    geminiKeyConnected: !!user.gemini_key_enc,
    geminiKeyValid: !!user.gemini_key_valid,
    geminiKeyUpdatedAt: user.gemini_key_updated_at,
  };
}

async function markUserVerified(db, userId) {
  await db.query('UPDATE users SET email_verified = true WHERE id = $1', [userId]);
}

async function setUserGeminiKey(db, userId, encryptedKey) {
  await db.query(
    'UPDATE users SET gemini_key_enc = $1, gemini_key_valid = true, gemini_key_updated_at = $2 WHERE id = $3',
    [encryptedKey, Date.now(), userId],
  );
}

async function clearUserGeminiKey(db, userId) {
  await db.query(
    'UPDATE users SET gemini_key_enc = NULL, gemini_key_valid = false, gemini_key_updated_at = $1 WHERE id = $2',
    [Date.now(), userId],
  );
}

async function updateUserPassword(db, userId, passwordHash) {
  await db.query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, userId]);
}

// Cascades across every table that references this user — a real "erase
// everything" for data-deletion requests, not just the account row. A real
// transaction now (checked-out client + BEGIN/COMMIT/ROLLBACK), replacing
// better-sqlite3's synchronous db.transaction() wrapper.
async function deleteUserCompletely(db, userId) {
  const user = await getUserById(db, userId);
  if (!user) return false;
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM drafts WHERE user_id = $1', [userId]);
    await client.query('DELETE FROM sessions WHERE user_id = $1', [userId]);
    await client.query('DELETE FROM email_verifications WHERE user_id = $1', [userId]);
    await client.query('DELETE FROM password_resets WHERE user_id = $1', [userId]);
    await client.query('DELETE FROM login_attempts WHERE identifier = $1', [`email:${user.email.toLowerCase()}`]);
    await client.query('DELETE FROM users WHERE id = $1', [userId]);
    await client.query('COMMIT');
    return true;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

// ---------- sessions ----------
async function createSession(db, { token, userId, expiresAt }) {
  await db.query(
    'INSERT INTO sessions (token, user_id, created_at, expires_at) VALUES ($1, $2, $3, $4)',
    [token, userId, Date.now(), expiresAt],
  );
}

async function getSession(db, token) {
  const result = await db.query('SELECT * FROM sessions WHERE token = $1', [token]);
  return result.rows[0] || null;
}

async function deleteSession(db, token) {
  await db.query('DELETE FROM sessions WHERE token = $1', [token]);
}

// Used after a password reset — a compromised account shouldn't stay logged
// in anywhere the attacker might already be.
async function deleteSessionsForUser(db, userId) {
  await db.query('DELETE FROM sessions WHERE user_id = $1', [userId]);
}

async function cleanupExpiredSessions(db) {
  await db.query('DELETE FROM sessions WHERE expires_at < $1', [Date.now()]);
}

// ---------- email verification tokens ----------
async function createEmailVerification(db, { token, userId, expiresAt }) {
  await db.query(
    'INSERT INTO email_verifications (token, user_id, created_at, expires_at) VALUES ($1, $2, $3, $4)',
    [token, userId, Date.now(), expiresAt],
  );
}

async function getEmailVerification(db, token) {
  const result = await db.query('SELECT * FROM email_verifications WHERE token = $1', [token]);
  return result.rows[0] || null;
}

async function deleteEmailVerificationsForUser(db, userId) {
  await db.query('DELETE FROM email_verifications WHERE user_id = $1', [userId]);
}

async function cleanupExpiredVerifications(db) {
  await db.query('DELETE FROM email_verifications WHERE expires_at < $1', [Date.now()]);
}

// ---------- password reset tokens ----------
async function createPasswordReset(db, { token, userId, expiresAt }) {
  await db.query(
    'INSERT INTO password_resets (token, user_id, created_at, expires_at) VALUES ($1, $2, $3, $4)',
    [token, userId, Date.now(), expiresAt],
  );
}

async function getPasswordReset(db, token) {
  const result = await db.query('SELECT * FROM password_resets WHERE token = $1', [token]);
  return result.rows[0] || null;
}

async function deletePasswordResetsForUser(db, userId) {
  await db.query('DELETE FROM password_resets WHERE user_id = $1', [userId]);
}

async function cleanupExpiredPasswordResets(db) {
  await db.query('DELETE FROM password_resets WHERE expires_at < $1', [Date.now()]);
}

// ---------- login/signup attempt tracking (for rate limiting) ----------
async function recordAttempt(db, identifier) {
  await db.query('INSERT INTO login_attempts (identifier, created_at) VALUES ($1, $2)', [identifier, Date.now()]);
}

async function countRecentFailures(db, identifier, windowMs) {
  const since = Date.now() - windowMs;
  const result = await db.query(
    'SELECT COUNT(*) AS n FROM login_attempts WHERE identifier = $1 AND created_at > $2',
    [identifier, since],
  );
  return result.rows[0].n;
}

async function clearFailures(db, identifier) {
  await db.query('DELETE FROM login_attempts WHERE identifier = $1', [identifier]);
}

// Keeps the table from growing forever — anything older than the retention
// window is no longer relevant to any rate-limit decision.
async function cleanupOldLoginAttempts(db, retentionMs) {
  await db.query('DELETE FROM login_attempts WHERE created_at < $1', [Date.now() - retentionMs]);
}

// ---------- drafts (always scoped to a user) ----------
// analysis/listings/selected stay as JSON-encoded TEXT, not native JSONB —
// a deliberately conservative choice for this migration. JSONB would let
// Postgres parse these natively (and drop the manual JSON.parse below), but
// changing the storage type and the async DB layer in the same pass, with no
// way to test against a live Postgres instance from here, is more risk than
// this needs. Worth revisiting once this is confirmed working for real.
function rowToDraft(row) {
  if (!row) return null;
  return {
    id: row.id,
    analysis: JSON.parse(row.analysis),
    thumb: row.thumb,
    listings: JSON.parse(row.listings),
    selected: JSON.parse(row.selected),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

async function listDrafts(db, userId) {
  const result = await db.query('SELECT * FROM drafts WHERE user_id = $1 ORDER BY updated_at DESC', [userId]);
  return result.rows.map(rowToDraft);
}

async function getDraft(db, userId, id) {
  const result = await db.query('SELECT * FROM drafts WHERE id = $1 AND user_id = $2', [id, userId]);
  return rowToDraft(result.rows[0]);
}

async function createDraft(db, userId, { analysis, thumb, selected }) {
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const now = Date.now();
  await db.query(
    `INSERT INTO drafts (id, user_id, analysis, thumb, listings, selected, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
    [id, userId, JSON.stringify(analysis), thumb || null, JSON.stringify({}), JSON.stringify(selected || []), now, now],
  );
  return getDraft(db, userId, id);
}

async function updateDraft(db, userId, id, patch) {
  const existing = await getDraft(db, userId, id);
  if (!existing) return null;

  const mergedListings = { ...existing.listings };
  if (patch.listings) {
    for (const [platform, fields] of Object.entries(patch.listings)) {
      mergedListings[platform] = { ...(mergedListings[platform] || {}), ...fields };
    }
  }

  await db.query(
    `UPDATE drafts SET analysis=$1, thumb=$2, listings=$3, selected=$4, updated_at=$5
     WHERE id=$6 AND user_id=$7`,
    [
      JSON.stringify(patch.analysis !== undefined ? patch.analysis : existing.analysis),
      patch.thumb !== undefined ? patch.thumb : existing.thumb,
      JSON.stringify(mergedListings),
      JSON.stringify(patch.selected !== undefined ? patch.selected : existing.selected),
      Date.now(),
      id, userId,
    ],
  );
  return getDraft(db, userId, id);
}

async function deleteDraft(db, userId, id) {
  await db.query('DELETE FROM drafts WHERE id = $1 AND user_id = $2', [id, userId]);
}

async function clearDrafts(db, userId) {
  await db.query('DELETE FROM drafts WHERE user_id = $1', [userId]);
}

module.exports = {
  initDb, migrate,
  createUser, getUserByEmail, getUserById, publicUser, markUserVerified,
  setUserGeminiKey, clearUserGeminiKey, updateUserPassword, deleteUserCompletely,
  createSession, getSession, deleteSession, deleteSessionsForUser, cleanupExpiredSessions,
  createEmailVerification, getEmailVerification, deleteEmailVerificationsForUser, cleanupExpiredVerifications,
  createPasswordReset, getPasswordReset, deletePasswordResetsForUser, cleanupExpiredPasswordResets,
  recordAttempt, countRecentFailures, clearFailures, cleanupOldLoginAttempts,
  listDrafts, getDraft, createDraft, updateDraft, deleteDraft, clearDrafts,
};
